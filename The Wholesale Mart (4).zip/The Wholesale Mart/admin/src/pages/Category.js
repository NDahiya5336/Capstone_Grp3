import React from "react";

function Category() {
  return (
    <div style={{ paddingTop: "5rem" }}>
      <h1>Category</h1>
    </div>
  );
}

export default Category;
