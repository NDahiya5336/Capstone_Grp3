import React from "react";

export default function Products() {
  return (
    <div style={{ paddingTop: "5rem" }}>
      <h1>Products</h1>
    </div>
  );
}
