import React from "react";

function AddProduct() {
  return (
    <div style={{ paddingTop: "5rem" }}>
      <h1>Add New Product</h1>
    </div>
  );
}

export default AddProduct;
