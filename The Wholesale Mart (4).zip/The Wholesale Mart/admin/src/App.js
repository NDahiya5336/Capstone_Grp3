import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Home from "./pages/Home";

import SideNavBar from "./components/SideNavBar";
import AddProduct from "./pages/AddProduct";
import Products from "./pages/Products";
import Category from "./pages/Category";

function App() {
  return (
    <Router>
      <div className="App">
        <SideNavBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/addProduct" element={<AddProduct />} />
          <Route path="/products" element={<Products />} />
          <Route path="/category" element={<Category />} />
        </Routes>
        <Home />
      </div>
    </Router>
  );
}

export default App;
