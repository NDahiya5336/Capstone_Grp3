import React from "react";
import { MDBNavbar, MDBContainer, MDBNavbarBrand } from "mdb-react-ui-kit";

export default function NavBar() {
  return (
    <>
      <MDBNavbar
        fixed="top"
        style={{
          left: "65px",
        }}
        light
        bgColor="light"
      >
        <MDBContainer fluid>
          <MDBNavbarBrand href="/" className="ps-3">
            TWM Admin
          </MDBNavbarBrand>
        </MDBContainer>
      </MDBNavbar>
    </>
  );
}
