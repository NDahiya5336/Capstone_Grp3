import React from "react";
import SideNav, { NavItem, NavIcon, NavText } from "@trendmicro/react-sidenav";

import { useNavigate } from "react-router-dom";

// Be sure to include styles at some point, probably during your bootstraping
import "@trendmicro/react-sidenav/dist/react-sidenav.css";

function SideNavBar() {
  const navigate = useNavigate();

  return (
    <SideNav
      onSelect={(selected) => {
        // Add your code here
        navigate("/" + selected);
      }}
      style={{ background: "#f0efed", color: "black" }}
    >
      <SideNav.Toggle style={{ color: "black" }} />
      <SideNav.Nav defaultSelected="home">
        <NavItem eventKey="home">
          <NavIcon>
            <i
              className="fa fa-fw fa-home"
              style={{ fontSize: "1.75em", color: "black" }}
            />
          </NavIcon>
          <NavText style={navTextStyle}>Home</NavText>
        </NavItem>
        <NavItem eventKey="category">
          <NavIcon>
            <i
              className="fa-sharp fa-solid fa-table-cells-large"
              style={{ fontSize: "1.75em", color: "black" }}
            />
          </NavIcon>
          <NavText style={navTextStyle}>Category</NavText>
        </NavItem>
        <NavItem eventKey="addProduct">
          <NavIcon>
            <i
              className="fa fa-fw fa-plus"
              style={{ fontSize: "1.75em", color: "black" }}
            />
          </NavIcon>
          <NavText style={navTextStyle}>Add Product</NavText>
        </NavItem>
        <NavItem eventKey="products">
          <NavIcon>
            <i
              className="fa fa-fw fa-list"
              style={{ fontSize: "1.75em", color: "black" }}
            />
          </NavIcon>
          <NavText style={navTextStyle}>Products</NavText>
        </NavItem>
      </SideNav.Nav>
    </SideNav>
  );
}

export default SideNavBar;

const navTextStyle = {
  color: "black",
  fontWeight: "500",
};
