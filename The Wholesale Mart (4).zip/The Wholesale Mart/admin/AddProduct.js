import React from "react";
import { Container, Form, Col, Row, Button } from "react-bootstrap";
import { useForm } from "react-hook-form";

export default function AddProduct() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  return (
    <div style={{ paddingTop: "5rem" }}>
      <h1>Add New Product</h1>
      <Container
        style={{
          padding: "6rem",
        }}
      >
        <Form onClick={handleSubmit}>
          <Form.Group as={Row} className="mb-3" controlId="formHorizontalName">
            <Form.Label style={style.lable} column sm={2}>
              Name
            </Form.Label>
            <Col sm={10}>
              <Form.Control
                name="name"
                type="text"
                placeholder="Product name"
                {...register("name", { required: true, minLength: 7 })}
              />
            </Col>
            {errors.name && <p>Please enter correct value for the name</p>}
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formHorizontalDetail"
          >
            <Form.Label style={style.lable} column sm={2}>
              Description
            </Form.Label>
            <Col sm={10}>
              <Form.Control
                as="textarea"
                name="description"
                placeholder="Product description goes here..."
                style={{ height: "13rem" }}
                {...register("description", {
                  required: true,
                  minLength: {
                    value: 100,
                    message: "Please provide full details for the description.",
                  },
                })}
              />
            </Col>
            {errors.description && <p>Please provide valid description</p>}
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formHorizontalCategory"
          >
            <Form.Label style={style.lable} column sm={2}>
              Category
            </Form.Label>
            <Form.Select
              sm={10}
              style={{ width: "81%", marginLeft: "10px" }}
              name="category"
              aria-label="Default select example"
              {...register("category", {
                required: true,
              })}
            >
              <option>Open this select menu</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </Form.Select>
            {errors.category && <p>Please select valid category.</p>}
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formHorizontalInStocks"
          >
            <Form.Label style={style.lable} column sm={2}>
              Available Stocks
            </Form.Label>
            <Col sm={10}>
              <Form.Control
                type="number"
                name="inStock"
                placeholder="Available stock numeber"
                {...register("inStock", {
                  required: true,
                })}
              />
            </Col>
            {errors.inStock && <p>Please enter value in 3 digit.</p>}
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formHorizontalRating"
          >
            <Form.Label style={style.lable} column sm={2}>
              Rating
            </Form.Label>
            <Col sm={10}>
              <Form.Control
                type="number"
                name="rating"
                placeholder="Rating for this product"
                {...register("rating", {
                  required: {
                    value: true,
                    message: "please provide decimal number.",
                  },
                })}
              />
            </Col>
            {errors.rating && <p>Please enter valid value for the rating.</p>}
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formHorizontalImages"
          >
            <Form.Label style={style.lable} column sm={2}>
              Images
            </Form.Label>
            <Col sm={10}>
              <Form.Control
                type="file"
                accept="images/*"
                multiple
                {...register("images", {
                  required: true,
                })}
                // onChange={changeMultipleFiles}
              />
            </Col>
            {errors.images && <p>Please select valid images.</p>}

            {/* The render function with the multiple image state */}
            {/* {render(multipleImages)} */}
          </Form.Group>

          <Form.Group as={Row} className="mb-3">
            <Col sm={{ span: 10, offset: 2 }}>
              <Button type="submit">Add Product</Button>
            </Col>
          </Form.Group>
        </Form>
      </Container>
    </div>
  );
}

const style = {
  lable: {
    fontSize: "1.2rem",
    fontWeight: "800",
  },
};
