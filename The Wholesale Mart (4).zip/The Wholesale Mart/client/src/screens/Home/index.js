import React from "react";
import { MDBCarousel, MDBCarouselItem } from "mdb-react-ui-kit";

import TodaysOffer from "../../components/TodaysOffer";
import BestSellingProducts from "../../components/BestSellingProducts";
import image1 from "../../assets/banner/01.jpeg";
import image2 from "../../assets/banner/02.jpeg";
import image3 from "../../assets/banner/03.jpeg";
import { useEffect, useState } from "react";

import ImageGalleryView from "../../components/ImageGallery";

export default function Home() {
  const [allProducts, setAllProducts] = useState([]);
  // const [category, setCategory] = useState();
  const [isLoading, setIsLoading] = useState(false);

  const fetchAllProduct = async () => {
    const response = await fetch("http://localhost:6000/getAllProducts");
    const data = await response.json();
    setAllProducts(data);
  };

  useEffect(() => {
    setIsLoading(true);
    fetchAllProduct();
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (allProducts.length === 0) return <h2>No product to display...</h2>;
  return (
    <>
      <MDBCarousel className="container w-70 h-30 mb-3" showControls>
        <MDBCarouselItem
          style={{ height: "30rem" }}
          className="w-100 d-block"
          itemId={1}
          src={image1}
          alt="..."
        />
        <MDBCarouselItem
          style={{ height: "30rem" }}
          className="w-100 d-block"
          itemId={2}
          src={image2}
          alt="..."
        />
        <MDBCarouselItem
          style={{ height: "30rem" }}
          className="w-100 d-block"
          itemId={3}
          src={image3}
          alt="..."
        />
      </MDBCarousel>
      <TodaysOffer products={allProducts} />
      <BestSellingProducts products={allProducts} />
      <ImageGalleryView products={allProducts} />
    </>
  );
}
