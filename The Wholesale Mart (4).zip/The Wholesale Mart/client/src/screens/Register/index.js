/* eslint-disable no-useless-escape */
import React from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBInput,
} from "mdb-react-ui-kit";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

import "./style.css";

function Register() {
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    console.log(data);

    console.log(`${process.env.REACT_APP_URL}/register`);

    fetch(`${process.env.REACT_APP_URL}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(async (res) => {
      const response = await res.json();
      console.log(response);
      if (response.status === 204) {
        console.log(response.message);
        navigate("/login");
      } else {
        console.log(response.message);
      }
    });
  };

  return (
    <MDBContainer className="my-5 gradient-form">
      <form onSubmit={handleSubmit(onSubmit)}>
        <MDBRow>
          <MDBCol col="6" className="mb-5">
            <div className="d-flex flex-column ms-5">
              <div className="text-center">
                <img
                  src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                  style={{ width: "185px" }}
                  alt="logo"
                />
                <h4 className="mt-1 mb-5 pb-1">We are The WholeSale Mart</h4>
              </div>

              <p>Register yourself.</p>

              <div className="mb-4">
                <MDBRow>
                  <MDBCol>
                    <MDBInput
                      label="First Name"
                      id="firstName"
                      name="firstName"
                      type="text"
                      {...register("firstName", {
                        required: true,
                        maxLength: 10,
                      })}
                    />
                    {errors.firstName && <p>Please check the First Name</p>}
                  </MDBCol>
                  <MDBCol>
                    <MDBInput
                      label="Last Name"
                      id="lastName"
                      name="lastName"
                      type="text"
                      {...register("lastName", {
                        required: true,
                        maxLength: 10,
                      })}
                    />
                    {errors.lastName && <p>Please check the Last Name</p>}
                  </MDBCol>
                </MDBRow>
              </div>
              <div className="mb-4">
                <MDBInput
                  label="Mobile Number"
                  id="phoneNumber"
                  name="phoneNumber"
                  type="number"
                  {...register("phoneNumber", {
                    required: true,
                    pattern:
                      // eslint-disable-next-line no-useless-escape
                      /^(\(\+[0-9]{2}\))?([0-9]{3}-?)?([0-9]{3})\-?([0-9]{4})(\/[0-9]{4})?$/gm,
                  })}
                />
                {errors.phoneNumber && <p>Please check the phone number</p>}
              </div>
              <div className="mb-4">
                <MDBInput
                  label="Email address"
                  id="email"
                  type="email"
                  name="email"
                  {...register("email", {
                    required: true,
                    pattern:
                      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                  })}
                />
                {errors.email && <p>Please check the Email</p>}
              </div>
              <div className="pb-4">
                <MDBInput
                  label="Password"
                  id="password"
                  name="password"
                  type="password"
                  {...register("password", {
                    required: true,
                    pattern: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15}$/,
                  })}
                />
                {errors.password && <p>Please check the Password</p>}
              </div>

              <div className="text-center pt-1 mb-5 pb-1">
                <MDBBtn className="mb-4 w-100 gradient-custom-2" type="submit">
                  Register
                </MDBBtn>
              </div>
            </div>
          </MDBCol>

          <MDBCol col="6" className="mb-5">
            <div className="d-flex flex-column  justify-content-center gradient-custom-2 h-100 mb-4">
              <div className="text-white px-3 py-4 p-md-5 mx-md-4">
                <h4 className="mb-4">We are more than just a company</h4>
                <p className="small mb-0 light">
                  Happy to provide the best deal in the town.
                </p>
              </div>
            </div>
          </MDBCol>
        </MDBRow>
      </form>
    </MDBContainer>
  );
}

export default Register;
