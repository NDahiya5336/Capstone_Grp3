import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import "./style.css";
import { useJwt } from "react-jwt";

function Account({ token }) {
  const { decodedToken } = useJwt(token);

  const [address, setAddress] = useState({});

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  useEffect(() => {
    setTimeout(() => {
      reset({
        firstName: decodedToken.firstName,
        lastName: decodedToken.lastName,
        phoneNumber: decodedToken.phoneNumber,
        email: decodedToken.email,
        addressLine1: address.addressLine1,
        addressLine2: address.addressLine2,
        city: address.city,
        province: address.province,
        zipcode: address.zipcode,
        country: address.country,
      });
    }, 2000);
  }, [address]);

  const fetchAddress = async (decodedToken) => {
    console.log(decodedToken.id);
    fetch(`${process.env.REACT_APP_URL}/getAddress/${decodedToken.id}`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    }).then(async (res) => {
      const response = await res.json();
      console.log(response);
      if (response.status === 204) {
        console.log(response.address);
        setAddress(response.address);
      } else {
        console.log(response.message);
      }
    });
  };

  useEffect(() => {
    fetchAddress(decodedToken);
  }, [decodedToken]);

  const onSubmit = (data) => {
    console.log(data);

    data = { ...data };

    console.log(JSON.stringify(data));

    fetch(`${process.env.REACT_APP_URL}/saveAddress`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, userID: decodedToken.id }),
    }).then(async (res) => {
      const response = await res.json();
      console.log(response);
      if (response.status === 204) {
        console.log(response.address);
        setAddress(response.address);
        // navigate("/login");
      } else {
        console.log(response.message);
      }
    });
  };

  return (
    <div className="container rounded bg-white mt-5 mb-5">
      <div className="d-flex justify-content-center">
        <form className="col-md-9 border-right">
          <div className="p-3 py-5">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h4 className="text-right">Profile Settings</h4>
            </div>
            <div className="row mt-1">
              <div className="col-md-6">
                <label className="labels">First Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="first name"
                  {...register("firstName", {
                    required: true,
                    maxLength: 10,
                  })}
                />
                {errors.firstName && <p>Please enter valid first name.</p>}
              </div>
              <div className="col-md-6">
                <label className="labels">Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  value=""
                  placeholder="last name"
                  {...register("lastName", {
                    required: true,
                    maxLength: 10,
                  })}
                />
                {errors.lastName && <p>Please enter valid last.</p>}
              </div>
            </div>
            <div className="row mt-1">
              <div className="col-md-12 mb-3">
                <label className="labels">Mobile Number</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="your phone number"
                  {...register("phoneNumber", {
                    required: true,
                    pattern:
                      // eslint-disable-next-line no-useless-escape
                      /^(\(\+[0-9]{2}\))?([0-9]{3}-?)?([0-9]{3})\-?([0-9]{4})(\/[0-9]{4})?$/gm,
                  })}
                />
                {errors.phoneNumber && <p>Please check the phone number</p>}
              </div>
              <div className="col-md-12 mb-1">
                <label className="labels">Email ID</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="your email address"
                  {...register("email", {
                    required: true,
                    pattern:
                      // eslint-disable-next-line no-useless-escape
                      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                  })}
                />
                {errors.email && <p>Please check the Email</p>}
              </div>
              <div className="col-md-12 mb-1">
                <label className="labels">Address Line 1</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="address line 1"
                  id="addressLine1"
                  name="addressLine1"
                  {...register("addressLine1", {
                    required: true,
                  })}
                />
                {errors.addressLine1 && <p>Address is required.</p>}
              </div>
              <div className="col-md-12 mb-1">
                <label className="labels">Address Line 2</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="address line 2"
                  id="addressLine2"
                  name="addressLine2"
                  {...register("addressLine2")}
                />
              </div>
              <div className="col-md-12 mb-1">
                <label className="labels">City</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="city"
                  id="city"
                  name="city"
                  {...register("city", {
                    required: true,
                  })}
                />
                {errors.city && <p>city is required.</p>}
              </div>
              <div className="col-md-12">
                <label className="labels">Zipcode</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="zipcode"
                  id="zipcode"
                  name="zipcode"
                  {...register("zipcode", {
                    required: true,
                  })}
                />
                {errors.zipcode && <p>Please provide valid Zipcode.</p>}
              </div>
            </div>
            <div className="row mt-1">
              <div className="col-md-6">
                <label className="labels">Country</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="country"
                  name="country"
                  id="country"
                  {...register("country", {
                    required: true,
                  })}
                />
                {errors.country && <p>Country is required.</p>}
              </div>
              <div className="col-md-6">
                <label className="labels">Province/Region</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="province"
                  id="province"
                  name="province"
                  {...register("province", {
                    required: true,
                  })}
                />
                {errors.province && <p>province is required</p>}
              </div>
            </div>
            <div className="mt-5 text-center">
              <button
                className="btn btn-primary profile-button"
                type="button"
                onClick={handleSubmit(onSubmit)}
              >
                Save Profile
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Account;
