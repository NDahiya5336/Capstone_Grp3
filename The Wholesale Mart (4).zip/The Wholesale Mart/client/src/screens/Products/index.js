import React, { useEffect, useState } from "react";
import styled from "styled-components";

import PageHero from "../../components/PageHero";
import Sort from "../../components/Sort";
import ProductList from "../../components/ProductList";

import Category from "../../components/Category";
import ProductListing from "../../components/ProductListing";
import Filters from "../../components/Filters";

function Products() {
  const [allProducts, setAllProducts] = useState([]);
  // const [category, setCategory] = useState();
  const [isLoading, setIsLoading] = useState(false);

  const fetchAllProduct = async () => {
    const response = await fetch("http://localhost:6000/getAllProducts");
    const data = await response.json();
    setAllProducts(data);
  };

  useEffect(() => {
    setIsLoading(true);
    fetchAllProduct();
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (allProducts.length === 0) return <h2>No product to display...</h2>;

  return (
    <main>
      <PageHero title="products" />
      <Wrapper className="page">
        <div className="section-center products">
          {/* <h1>Filters</h1> */}
          <Filters />
          <div>
            {/* <h1>List</h1> */}
            <Sort length={allProducts.length} />
            <ProductList products={allProducts} />
          </div>
        </div>
      </Wrapper>
    </main>
  );
}

const Wrapper = styled.div`
  .products {
    display: grid;
    gap: 3rem 1.5rem;
    margin: 4rem auto;
  }
  @media (min-width: 768px) {
    .products {
      grid-template-columns: 200px 1fr;
    }
  }
`;

export default Products;
