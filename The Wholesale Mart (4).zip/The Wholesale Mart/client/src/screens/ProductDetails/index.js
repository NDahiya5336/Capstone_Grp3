import React from "react";
import styled from "styled-components";
import { Link, useLocation } from "react-router-dom";

import PageHero from "../../components/PageHero";
import ProductImages from "../../components/ProductImages";
import Stars from "../../components/Stars";
import AddToCart from "../../components/AddToCart";

function ProductDetails() {
  const { state } = useLocation();

  console.log(state);

  return (
    <Wrapper>
      <PageHero title={state.name.substring(0, 150)} product />
      <div className="section section-center page">
        <Link to="/products" className="btn">
          back to products
        </Link>
        <div className="product-center">
          <ProductImages images={state.images} />
          <section className="content">
            <h2>{state.name}</h2>
            <Stars stars={state.rating} />
            <h5 className="price">${state.price}</h5>
            <p className="info">
              <span>Category :</span>
              {state.category}
            </p>
            <pre className="desc">{state.description}</pre>
            <p className="info">
              <span>Available : </span>
              {state.inStock > 0 ? state.inStock : "out of stock"}
            </p>
            <hr />
            {state.inStock > 0 && <AddToCart product={state} />}
          </section>
        </div>
      </div>
    </Wrapper>
  );
}

const Wrapper = styled.main`
  .product-center {
    display: grid;
    gap: 4rem;
    margin-top: 2rem;
  }
  .price {
    color: var(--clr-primary-5);
  }
  .desc {
    line-height: 2;
    max-width: 45em;
  }
  .info {
    text-transform: capitalize;
    width: 300px !importnant;
    display: grid;
    grid-template-columns: 125px 1fr;
    span {
      font-weight: 700 !important;
    }
  }

  @media (min-width: 992px) {
    .product-center {
      grid-template-columns: 1fr 1fr;
      align-items: center;
    }
    .price {
      font-size: 1.25rem;
    }
  }
`;

export default ProductDetails;
