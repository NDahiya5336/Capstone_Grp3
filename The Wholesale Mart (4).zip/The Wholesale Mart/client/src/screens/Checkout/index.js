import React from "react";
import styled from "styled-components";
import PageHero from "../../components/PageHero";

// extra imports

import { useCartContext } from "../../context/cart_context";
import { Link } from "react-router-dom";

import ChechOutForm from "../../components/ChechOutForm";
import { MDBCol, MDBContainer } from "mdb-react-ui-kit";

const Checkout = () => {
  const { cart } = useCartContext();

  return (
    <main>
      <PageHero title="checkout" />
      <Wrapper className="page">
        {cart.length < 1 ? (
          <div className="empty">
            <h2>Your cart is empty</h2>
            <Link to="/products" className="btn">
              fill it
            </Link>
          </div>
        ) : (
          <MDBContainer>
            <MDBCol>
              <ChechOutForm />
            </MDBCol>
          </MDBContainer>
        )}
      </Wrapper>
    </main>
  );
};
const Wrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  .empty {
    text-align: center;
  }
`;
export default Checkout;
