import React from "react";
import {
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRipple,
  MDBCardGroup,
} from "mdb-react-ui-kit";

import styled from "styled-components";
import { Link } from "react-router-dom";

function BestSellingProducts({ products }) {
  return (
    <div className="container-bg py-5">
      <MDBContainer fluid className="my-5 text-center w-75">
        <h2 className="mt-4 mb-5">
          <strong>Bestsellers</strong>
        </h2>

        <MDBCardGroup>
          {products.slice(20, 23).map((product) => {
            const { _id, images, category, name, price, description } = product;
            return (
              <MDBCard className="me-2">
                <MDBRipple
                  rippleColor="light"
                  rippleTag="div"
                  className="bg-image rounded hover-zoom"
                >
                  <MDBCardImage
                    src={`${process.env.REACT_APP_URL}/${images[0].path}`}
                    fluid
                    className="w-100"
                  />
                  <a href="#!">
                    <div className="mask">
                      <div className="d-flex justify-content-start align-items-end h-100">
                        <h5>
                          <span className="badge bg-success ms-2">
                            Deal of the Day
                          </span>
                        </h5>
                      </div>
                    </div>
                    <div className="hover-overlay">
                      <div
                        className="mask"
                        style={{
                          backgroundColor: "rgba(251, 251, 251, 0.15)",
                        }}
                      ></div>
                    </div>
                  </a>
                </MDBRipple>
                <MDBCardBody>
                  <a href="#!" className="text-reset">
                    <h5 className="card-title mb-3">{name}</h5>
                  </a>
                  <a href="/" className="text-reset">
                    <p>{category}</p>
                  </a>
                  <h6 className="mb-3">${price}</h6>
                  <Link to={`/productDetails`} state={product} className="btn">
                    Details
                  </Link>
                </MDBCardBody>
              </MDBCard>
            );
          })}
        </MDBCardGroup>
        <br />
        <MDBCardGroup>
          {products.slice(29, 32).map((product) => {
            const { _id, images, category, name, price, description } = product;
            return (
              <MDBCard className="me-2">
                <MDBRipple
                  rippleColor="light"
                  rippleTag="div"
                  className="bg-image rounded hover-zoom"
                >
                  <MDBCardImage
                    src={`${process.env.REACT_APP_URL}/${images[0].path}`}
                    fluid
                    className="w-100"
                  />
                  <a href="#!">
                    <div className="mask">
                      <div className="d-flex justify-content-start align-items-end h-100">
                        <h5>
                          <span className="badge bg-danger ms-2">Hot Deal</span>
                        </h5>
                      </div>
                    </div>
                    <div className="hover-overlay">
                      <div
                        className="mask"
                        style={{
                          backgroundColor: "rgba(251, 251, 251, 0.15)",
                        }}
                      ></div>
                    </div>
                  </a>
                </MDBRipple>
                <MDBCardBody>
                  <a href="#!" className="text-reset">
                    <h5 className="card-title mb-3">{name}</h5>
                  </a>
                  <a href="/" className="text-reset">
                    <p>{category}</p>
                  </a>
                  <h6 className="mb-3">${price}</h6>
                  <Link to={`/productDetails`} state={product} className="btn">
                    Details
                  </Link>
                </MDBCardBody>
              </MDBCard>
            );
          })}
        </MDBCardGroup>
      </MDBContainer>
    </div>
  );
}

export default BestSellingProducts;

// function ProductList({ products }) {
//   return (
//     <>
//       {products.map((product) => {
//         const { _id, images, name, price, description } = product;
//         return (
//           <article key={_id}>
//             <img
//               src={`${process.env.REACT_APP_URL}/${images[0].path}`}
//               style={{ objectFit: "scale-down" }}
//               alt={name}
//             />
//             <div>
//               <h4>{name}</h4>
//               <h5 className="price">${price}</h5>
//               <p>{description.substring(0, 150)}...</p>
//               <Link to={`/productDetails`} state={product} className="btn">
//                 Details
//               </Link>
//             </div>
//           </article>
//         );
//       })}
//     </>
//   );
// }
