import React, { useEffect, useState } from "react";
import {
  MDBBtn,
  MDBCard,
  MDBCardBody,
  MDBCardHeader,
  MDBCol,
  MDBContainer,
  MDBInput,
  MDBRow,
  MDBTypography,
} from "mdb-react-ui-kit";

import { useForm } from "react-hook-form";
import { useJwt } from "react-jwt";

import CartTotals from "./CartTotals";
import useToken from "../hooks/useToken";
import { useNavigate } from "react-router-dom";

export default function ChechOutForm() {
  const { token } = useToken();
  const { decodedToken } = useJwt(token);
  const navigate = useNavigate();

  const [address, setAddress] = useState({});

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  useEffect(() => {
    setTimeout(() => {
      reset({
        firstName: decodedToken.firstName,
        lastName: decodedToken.lastName,
        phoneNumber: decodedToken.phoneNumber,
        email: decodedToken.email,
        addressLine1: address.addressLine1,
        addressLine2: address.addressLine2,
        city: address.city,
        province: address.province,
        zipcode: address.zipcode,
        country: address.country,
      });
    }, 2000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address]);

  const fetchAddress = async (decodedToken) => {
    console.log(decodedToken.id);
    console.log(`${process.env.REACT_APP_URL}/getAddress/${decodedToken.id}`);
    fetch(`${process.env.REACT_APP_URL}/getAddress/${decodedToken.id}`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    }).then(async (res) => {
      const response = await res.json();
      console.log(response);
      if (response.status === 204) {
        console.log(response.address);
        setAddress(response.address);
      } else {
        console.log(response.message);
      }
    });
  };

  useEffect(() => {
    fetchAddress(decodedToken);
  }, [decodedToken]);

  const onSubmit = (data) => {
    console.log(data);

    data = { ...data };

    console.log(JSON.stringify(data));

    fetch(`${process.env.REACT_APP_URL}/saveAddress`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, userID: decodedToken.id }),
    }).then(async (res) => {
      const response = await res.json();
      console.log(response);
      if (response.status === 204) {
        console.log(response.address);
        setAddress(response.address);
        navigate("/payment");
      } else {
        console.log(response.message);
      }
    });
  };

  return (
    <MDBContainer fluid className="py-5">
      <MDBRow className="">
        <MDBCol md="8" className="mb-4">
          <MDBCard className="mb-4">
            <MDBCardHeader className="py-3">
              <MDBTypography tag="h5" className="mb-0 text-font text-uppercase">
                Delivery address
              </MDBTypography>
            </MDBCardHeader>
            <MDBCardBody>
              <form>
                <MDBRow className="mb-4">
                  <MDBCol>
                    <MDBInput
                      label="First name"
                      name="firstName"
                      type="text"
                      {...register("firstName", {
                        required: true,
                        maxLength: 10,
                      })}
                    />
                    {errors.firstName && <p>Please enter valid first name.</p>}
                  </MDBCol>
                  <MDBCol>
                    <MDBInput
                      label="Last name"
                      name="lastName"
                      type="text"
                      {...register("lastName", {
                        required: true,
                        maxLength: 10,
                      })}
                    />
                    {errors.lastName && <p>Please enter valid last.</p>}
                  </MDBCol>
                </MDBRow>

                <MDBInput
                  label="Phone"
                  name="phone"
                  type="text"
                  className="mb-4"
                  {...register("phoneNumber", {
                    required: true,
                    pattern:
                      // eslint-disable-next-line no-useless-escape
                      /^(\(\+[0-9]{2}\))?([0-9]{3}-?)?([0-9]{3})\-?([0-9]{4})(\/[0-9]{4})?$/gm,
                  })}
                />
                {errors.phoneNumber && <p>Please check the phone number</p>}

                <MDBInput
                  label="Email"
                  name="email"
                  type="text"
                  className="mb-4"
                  {...register("email", {
                    required: true,
                    pattern:
                      // eslint-disable-next-line no-useless-escape
                      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                  })}
                />
                {errors.email && <p>Please check the Email</p>}

                <MDBInput
                  label="Address line 1"
                  type="text"
                  className="mb-4"
                  {...register("addressLine1", {
                    required: true,
                  })}
                />
                {errors.addressLine1 && <p>Address is required.</p>}
                <MDBInput
                  label="Address line 2"
                  type="text"
                  name="addressLine2"
                  className="mb-4"
                  {...register("addressLine2")}
                />
                <MDBInput
                  label="Zip Code"
                  type="text"
                  name="zipcode"
                  className="mb-4"
                  {...register("zipcode", {
                    required: true,
                  })}
                />
                {errors.zipcode && <p>Please provide valid Zipcode.</p>}
                <MDBInput
                  label="City"
                  name="city"
                  type="text"
                  className="mb-4"
                  {...register("city", {
                    required: true,
                  })}
                />
                {errors.city && <p>city is required.</p>}
                <MDBInput
                  label="Province"
                  name="Province"
                  type="text"
                  className="mb-4"
                  {...register("province", {
                    required: true,
                  })}
                />
                {errors.province && <p>province is required</p>}
                <MDBInput
                  label="Country"
                  type="text"
                  className="mb-4"
                  name="country"
                  {...register("country", {
                    required: true,
                  })}
                />
                {errors.country && <p>Country is required.</p>}
              </form>
            </MDBCardBody>
          </MDBCard>
          <div className="text-center">
            <MDBBtn
              onClick={handleSubmit(onSubmit)}
              className="w-100 button-order col-md-10"
            >
              Save Changes
            </MDBBtn>
          </div>
        </MDBCol>
        <MDBCol md="4">
          <CartTotals isShown={false} />
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}
