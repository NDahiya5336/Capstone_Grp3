import React from "react";
import {
  MDBDropdown,
  MDBDropdownItem,
  MDBDropdownMenu,
  MDBDropdownToggle,
} from "mdb-react-ui-kit";

import { useNavigate } from "react-router-dom";

import useToken from "../hooks/useToken";

function UserActions({ decodedToken }) {
  const navigate = useNavigate();

  const { setToken } = useToken();

  const handleLogout = () => {
    console.log("logout");
    setToken("");
    navigate("/");
    window.location.reload(false);
  };

  return (
    <MDBDropdown className="ps-4 mt-2">
      <MDBDropdownToggle
        tag="h5"
        style={{
          color: "black",
          cursor: "pointer",
        }}
      >
        hey, {decodedToken.firstName}
      </MDBDropdownToggle>
      <MDBDropdownMenu className="mt-3">
        <MDBDropdownItem link href="/account">
          Account
        </MDBDropdownItem>
        <MDBDropdownItem link href="/account">
          Orders
        </MDBDropdownItem>
        <MDBDropdownItem divider />
        <MDBDropdownItem link onClick={handleLogout}>
          Logout
        </MDBDropdownItem>
      </MDBDropdownMenu>
    </MDBDropdown>
  );
}

export default UserActions;
