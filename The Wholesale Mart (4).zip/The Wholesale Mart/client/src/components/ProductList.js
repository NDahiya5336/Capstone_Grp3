import React from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";

function ProductList({ products }) {
  return (
    <Wrapper>
      {products.map((product) => {
        const { _id, images, name, price, description } = product;
        return (
          <article key={_id}>
            <img
              src={`${process.env.REACT_APP_URL}/${images[0].path}`}
              style={{ objectFit: "scale-down" }}
              alt={name}
            />
            <div>
              <h4>{name}</h4>
              <h5 className="price">${price}</h5>
              <p>{description.substring(0, 150)}...</p>
              <Link to={`/productDetails`} state={product} className="btn">
                Details
              </Link>
            </div>
          </article>
        );
      })}
    </Wrapper>
  );
}

const Wrapper = styled.section`
  display: grid;
  row-gap: 3rem;

  img {
    width: 100%;
    display: block;
    width: 300px;
    height: 200px;
    object-fit: cover;
    border-radius: 5px;
    margin-bottom: 1rem;
  }
  h4 {
    margin-bottom: 0.5rem;
  }
  .price {
    color: var(--clr-primary-6);
    margin-bottom: 0.75rem;
  }
  p {
    max-width: 45em;
    margin-bottom: 1rem;
  }
  .btn {
    font-size: 0.5rem;
    padding: 0.25rem 0.5rem;
    background: #ab7a5f;
  }
  .btn:hover {
    background: #c5a491;
    color: #453227;
  }
  @media (min-width: 992px) {
    article {
      display: grid;
      grid-template-columns: auto 1fr;
      column-gap: 2rem;
      align-items: center;
    }
  }
`;

export default ProductList;
