import React from "react";
import {
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRipple,
  MDBCardGroup,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";
function ImageGalleryView({ products }) {
  return (
    <div className="container-bg py-5">
      <MDBContainer fluid className="my-5 text-center w-75">
        <h2 className="mt-4 mb-5">
          <strong>Product Gallary</strong>
        </h2>

        <MDBCardGroup>
          {products.slice(24, 27).map((product) => {
            const { _id, images, category, name, price, description } = product;
            return (
              <MDBCard className="me-2">
                <MDBRipple
                  rippleColor="light"
                  rippleTag="div"
                  className="bg-image rounded hover-zoom"
                >
                  <MDBCardImage
                    src={`${process.env.REACT_APP_URL}/${images[0].path}`}
                    fluid
                    className="w-100"
                  />
                </MDBRipple>
                <MDBCardBody>
                  <a href="#!" className="text-reset">
                    <h5 className="card-title mb-3">{name}</h5>
                  </a>
                  <Link to={`/productDetails`} state={product} className="btn">
                    More
                  </Link>
                </MDBCardBody>
              </MDBCard>
            );
          })}
        </MDBCardGroup>
      </MDBContainer>
    </div>
  );
}
export default ImageGalleryView;
