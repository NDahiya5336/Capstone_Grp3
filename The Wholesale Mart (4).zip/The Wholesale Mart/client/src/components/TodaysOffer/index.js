import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBIcon,
  MDBCardGroup,
} from "mdb-react-ui-kit";
import Stars from "../../components/Stars";
import { Link } from "react-router-dom";
function TodaysOffer({ products }) {
  return (
    <div className="container-bg py-5">
      <MDBContainer fluid className=" w-75 text-center">
        <h3 className="mt-4 mb-5">
          <strong>Today's Offer</strong>
        </h3>
        <MDBCardGroup>
          {products.slice(26, 29).map((product) => {
            const {
              _id,
              rating,
              images,
              inStock,
              category,
              name,
              price,
              description,
            } = product;
            return (
              <MDBCard key={_id} className="me-2">
                <div className="d-flex justify-content-between p-3">
                  <p className="lead mb-0">Today's Combo Offer</p>
                  <div
                    className="bg-info rounded-circle d-flex align-items-center justify-content-center shadow-1-strong"
                    style={{ width: "35px", height: "35px" }}
                  >
                    <p className="text-white mb-0 small">x2</p>
                  </div>
                </div>
                <MDBCardImage
                  src={`${process.env.REACT_APP_URL}/${images[0].path}`}
                  position="top"
                  alt="Laptop"
                />
                <MDBCardBody>
                  <div className="d-flex justify-content-between">
                    <p className="small">
                      <a href="#!" className="text-muted">
                        {category}
                      </a>
                    </p>
                    <p className="small text-danger">
                      <s> 20%</s>
                    </p>
                  </div>

                  <div className="d-flex justify-content-between mb-3">
                    <h5 className="mb-0">{name}</h5>
                    <h5 className="text-dark mb-0">${price}</h5>
                  </div>

                  <div class="d-flex justify-content-between mb-2">
                    <p class="text-muted mb-0">
                      Stock: <span class="fw-bold">{inStock}</span>
                    </p>
                    <Stars stars={rating} />
                    <Link
                      to={`/productDetails`}
                      state={product}
                      className="btn"
                    >
                      Details
                    </Link>
                  </div>
                </MDBCardBody>
              </MDBCard>
            );
          })}
        </MDBCardGroup>
        <br />
        <MDBCardGroup>
          {products.slice(6, 9).map((product) => {
            const {
              _id,
              rating,
              images,
              inStock,
              category,
              name,
              price,
              description,
            } = product;
            return (
              <MDBCard className="me-2">
                <div className="d-flex justify-content-between p-3">
                  <p className="lead mb-0">Deal's on Books</p>
                  <div
                    className="bg-info rounded-circle d-flex align-items-center justify-content-center shadow-1-strong"
                    style={{ width: "35px", height: "35px" }}
                  >
                    <p className="text-white mb-0 small">x1</p>
                  </div>
                </div>
                <MDBCardImage
                  src={`${process.env.REACT_APP_URL}/${images[0].path}`}
                  position="top"
                  alt="Laptop"
                />
                <MDBCardBody>
                  <div className="d-flex justify-content-between">
                    <p className="small">
                      <a href="#!" className="text-muted">
                        {category}
                      </a>
                    </p>
                    <p className="small text-danger">
                      <s> 20%</s>
                    </p>
                  </div>

                  <div className="d-flex justify-content-between mb-3">
                    <h5 className="mb-0">{name}</h5>
                    <h5 className="text-dark mb-0">${price}</h5>
                  </div>

                  <div class="d-flex justify-content-between mb-2">
                    <p class="text-muted mb-0">
                      Stock: <span class="fw-bold">{inStock}</span>
                    </p>
                    <Stars stars={rating} />
                    <Link
                      to={`/productDetails`}
                      state={product}
                      className="btn"
                    >
                      Details
                    </Link>
                  </div>
                </MDBCardBody>
              </MDBCard>
            );
          })}
        </MDBCardGroup>
      </MDBContainer>
    </div>
  );
}
export default TodaysOffer;
// import {
//   MDBContainer,
//   MDBRow,
//   MDBCol,
//   MDBCard,
//   MDBCardGroup,
//   MDBCardBody,
//   MDBCardImage,
//   MDBIcon,
// } from "mdb-react-ui-kit";

// import React from "react";
// import styled from "styled-components";
// import { Link } from "react-router-dom";

// export default TodaysOffer;

// function TodaysOffer({ products }) {
//   return (
//     <>
//       <MDBContainer fluid className=" w-75 text-center">
//         <h3 className="mt-4 mb-5">
//           <strong>Today's Offer</strong>
//         </h3>
//       </MDBContainer>
//       <MDBCardGroup>
//         {products.slice(15, 19).map((product) => {
//           const { _id, images, name, price, description } = product;
//           return (
//             <article key={_id}>
//               {/* <MDBRow>
//                     <MDBCol md="12" lg="4" className="mb-4 mb-lg-0"> */}
//               <MDBCard>
//                 <MDBCardImage
//                   src={`${process.env.REACT_APP_URL}/${images[0].path}`}
//                   position="top"
//                   alt={name}
//                 />
//                 {/* <img
//                   src={`${process.env.REACT_APP_URL}/${images[0].path}`}
//                   style={{ objectFit: "scale-down" }}
//                   alt={name}
//                 /> */}

//                 <MDBCardBody>
//                   <brs />
//                   <div className="d-flex justify-content-between mb-3">
//                     <h5 className="mb-0">{name}</h5>
//                     <h5 className="text-dark mb-0">${price}</h5>
//                   </div>

//                   <div class="d-flex justify-content-between mb-2">
//                     <p class="text-muted mb-0">
//                       {/* Available: <span class="fw-bold">6</span> */}
//                       <Link
//                         to={`/productDetails`}
//                         state={product}
//                         className="btn"
//                       >
//                         Details
//                       </Link>
//                     </p>
//                     <div class="ms-auto text-warning">
//                       <MDBIcon fas icon="star" />
//                       <MDBIcon fas icon="star" />
//                       <MDBIcon fas icon="star" />
//                       <MDBIcon fas icon="star" />
//                       <MDBIcon fas icon="star" />
//                     </div>
//                   </div>
//                 </MDBCardBody>
//               </MDBCard>
//               {/* <h5 className="price">${price}</h5> */}
//               {/* <p>{description.substring(0, 150)}...</p> */}
//               {/* <Link to={`/productDetails`} state={product} className="btn">
//                     Details
//                   </Link> */}
//               {/* </MDBCol>
//                   </MDBRow> */}
//             </article>
//           );
//         })}
//       </MDBCardGroup>
//     </>
//   );
// }

// const Wrapper = styled.section`
//   display: grid;
//   row-gap: 3rem;

//   img {
//     width: 100%;
//     display: block;
//     width: 300px;
//     height: 200px;
//     object-fit: cover;
//     border-radius: 5px;
//     margin-bottom: 1rem;
//   }
//   h4 {
//     margin-bottom: 0.5rem;
//   }
//   .price {
//     color: var(--clr-primary-6);
//     margin-bottom: 0.75rem;
//   }
//   p {
//     max-width: 45em;
//     margin-bottom: 1rem;
//   }
//   .btn {
//     font-size: 0.5rem;
//     padding: 0.25rem 0.5rem;
//     background: #ab7a5f;
//   }
//   .btn:hover {
//     background: #c5a491;
//     color: #453227;
//   }
//   @media (min-width: 992px) {
//     article {
//       display: grid;
//       grid-template-columns: auto 1fr;
//       column-gap: 2rem;
//       align-items: center;
//     }
//   }
// `;
