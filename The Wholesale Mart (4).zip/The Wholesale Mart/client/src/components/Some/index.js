import React from "react";

function Some({ productDetails }) {
  return <div>{productDetails.name}</div>;
}

export default Some;
