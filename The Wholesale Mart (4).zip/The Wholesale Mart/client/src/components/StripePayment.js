import React from "react";
import Stripe from "react-stripe-checkout";
import axios from "axios";
import { useCartContext } from "../context/cart_context";
import { useNavigate } from "react-router-dom";

function StripePayment() {
  const { total_amount } = useCartContext();
  const navigate = useNavigate();

  const handleToken = async (totalAmount, token) => {
    try {
      const res = await axios.post(`${process.env.REACT_APP_URL}/payment`, {
        token: token,
        amount: totalAmount,
      });
      console.log(res);
      navigate("/");
    } catch (error) {
      console.log(error);
    }
  };

  const tokenHandler = (token) => {
    handleToken(total_amount, token);
  };

  return (
    <div style={{ display: "grid" }}>
      <Stripe
        stripeKey="pk_test_51MtJ8rImRCZcV24GyIxKcbjfsX6WAujOcdRsXqCYPrE6ViN1sgyCvDEXgwrUHryQZUkphcYzf0Bne4dBrAfrqHfT00ayyDbMX4"
        token={tokenHandler}
      />
    </div>
  );
}

export default StripePayment;
