import React from "react";
import { MDBContainer, MDBRow, MDBCol, MDBRipple } from "mdb-react-ui-kit";

import Automative from "../../assets/category/automative.jpg";
import Electronics from "../../assets/category/electronics.jpg";
import Books from "../../assets/category/books.jpg";
import Clothing from "../../assets/category/clothing.jpg";
import Furniture from "../../assets/category/furniture.jpg";
import Kitchen from "../../assets/category/kitchen.jpg";

function Category() {
  return (
    <div className="container-bg py-5">
      <MDBContainer fluid className="text-center w-75">
        <h4 className="mt-4 mb-5">
          <strong>Shop by Category</strong>
        </h4>

        <MDBRow>
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Automative} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Automative</p>
            </MDBRipple>
          </MDBCol>
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Electronics} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Electronics</p>
            </MDBRipple>
          </MDBCol>{" "}
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Clothing} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Clothing</p>
            </MDBRipple>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Furniture} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Furniture</p>
            </MDBRipple>
          </MDBCol>{" "}
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Kitchen} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Kitchen</p>
            </MDBRipple>
          </MDBCol>{" "}
          <MDBCol md="12" lg="4" className="mb-4 ">
            <MDBRipple
              rippleColor="dark"
              rippleTag="div"
              className="bg-image rounded hover-zoom shadow-1-strong rounded-circle"
            >
              <a href="/">
                <img src={Books} fluid style={style.imgStyle} alt="" />
              </a>
              <p style={style.textStyle}>Books</p>
            </MDBRipple>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

const style = {
  textStyle: {
    fontWeight: "600",
    fontSize: "1.2rem",
  },

  imgStyle: {
    width: "22vw",
    height: "200px",
  },
};

export default Category;
