import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";

import Home from "./screens/Home";
import Products from "./screens/Products";
import ProductDetails from "./screens/ProductDetails";
import About from "./screens/About";
import Login from "./screens/Login";
import Register from "./screens/Register";

import useToken from "./hooks/useToken";

import NavBar from "./components/NavBar";
import Footer from "./components/Footer";
import Cart from "./screens/Cart";
import Checkout from "./screens/Checkout";
import Account from "./screens/Account";

function App() {
  const { token, setToken } = useToken();

  return (
    <>
      <Router>
        <NavBar />
        <div className="">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/productDetails" element={<ProductDetails />} />
            <Route path="/about" element={<About />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route
              path="/login"
              element={
                token ? <Navigate to="/" /> : <Login setToken={setToken} />
              }
            />
            <Route
              path="/register"
              element={token ? <Navigate to="/" /> : <Register />}
            />
            <Route
              path="/account"
              element={token ? <Account token={token} /> : <Navigate to="/" />}
            />
          </Routes>
        </div>
        <Footer />
      </Router>
    </>
  );
}

export default App;
