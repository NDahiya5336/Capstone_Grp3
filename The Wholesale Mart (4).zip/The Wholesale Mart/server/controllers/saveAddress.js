const Address = require("../models/Address");

const saveAddress = async (req, res) => {
  console.log(req.body);

  const {
    addressLine1,
    addressLine2,
    city,
    zipcode,
    country,
    province,
    userID,
  } = req.body;

  try {
    const getAddress = await Address.findOne({
      userID,
    });

    if (getAddress) {
      getAddress.addressLine1 = addressLine1;
      getAddress.addressLine2 = addressLine2;
      getAddress.city = city;
      getAddress.zipcode = zipcode;
      getAddress.country = country;
      getAddress.province = province;

      const updatedAddress = await getAddress.save();
      return res.send({ status: 204, address: updatedAddress });
    }
    const address = new Address({
      addressLine1,
      addressLine2: addressLine2 || "",
      zipcode,
      city,
      country,
      province,
      userID,
    });

    const newAdd = await address.save();
    return res.send({ status: 204, address: newAdd });
  } catch (error) {
    console.log(error);
  }
};

module.exports = saveAddress;
