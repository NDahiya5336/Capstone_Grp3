const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const User = require("../models/User");

module.exports = async (req, res) => {
  console.log(req.body);

  // Get User email
  const user = await User.findOne({ email: req.body.email });
  if (!user)
    return res.send({
      status: 404,
      message: "Email not found",
    });

  // Compare password
  const isMatch = await bcrypt.compare(req.body.password, user.password);
  if (!isMatch) return res.send({ status: 400, message: "Invalid password" });

  try {
    const jsonToken = jwt.sign(
      {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        phoneNumber: user.phoneNumber,
        email: user.email,
      },
      process.env.TOKEN_SECRET,
      { expiresIn: "3d" }
    );
    console.log(jsonToken);

    const { password, ...others } = user;

    return res.header("x-auth-token", jsonToken).send({
      status: 200,
      message: "Yeah, you have accessed",
      token: jsonToken,
      ...others,
    });
  } catch (error) {
    return res.send({ status: 400, message: "Error genrating token" });
  }
};
