const stripe = require("stripe")(
  "sk_test_51MtJ8rImRCZcV24GILsuxoS80D16ny4N6FhvJa7FXvMxZz7b0e11TTddKrMhcsUdjk2alWMhXE6yP5C57AYZdlt700gL0ofdjC"
);
const { v4: uuidv4 } = require("uuid");

module.exports = async (req, res, next) => {
  console.log(req.body);
  const { token, amount } = req.body;
  const idempotencyKey = uuidv4();

  return stripe.customers
    .create({
      email: token.email,
      source: token,
    })
    .then((customer) => {
      stripe.charges.create(
        {
          amount: amount * 100,
          currency: "cad",
          customer: customer.id,
          receipt_email: token.email,
        },
        { idempotencyKey }
      );
    })
    .then((result) => {
      res.send({ code: 200, message: result });
    })
    .catch((err) => {
      console.log(err);
    });
};
