const fs = require("fs");

const Product = require("../models/Product");

const addProduct = async (req, res, next) => {
  const files = req.files;
  console.log(req.body);

  if (!files) {
    const error = new Error("Please choose files");
    error.httpStatusCode = 400;
    return next(error);
  }

  let product = await Product.create({
    images: req.files,
    ...req.body,
  });

  console.log(product);
  res.send(product);
};

module.exports = addProduct;

// Promise.all(result)
//   .then((msg) => {
//     // res.json(msg);
//     res.redirect("/");
//   })
//   .catch((err) => {
//     res.json(err);
//   });
