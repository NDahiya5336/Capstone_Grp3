const Address = require("../models/Address");

const getAddress = async (req, res) => {
  const userID = req.params.id;
  console.log(userID);

  try {
    const address = await Address.findOne({
      userID,
    });
    return res.send({ status: 204, address });
  } catch (error) {
    console.log(error);
  }
};

module.exports = getAddress;
