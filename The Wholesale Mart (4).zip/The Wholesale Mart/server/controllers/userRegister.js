const User = require("../models/User");

module.exports = async (req, res) => {
  console.log(req.body);
  const { firstName, lastName, email, phoneNumber, password, hashedPassword } =
    req.body;

  try {
    const isExist = await User.findOne({ email });

    if (isExist) {
      console.log(isExist);
      return res.send({
        status: 201,
        message: "Email address is already in use",
      });
    }

    const user = new User({
      firstName: firstName,
      lastName,
      email,
      phoneNumber,
      password: hashedPassword,
    });

    const newUser = await user.save();
    console.log(newUser);
    return res.send({ status: 204, message: "Registration successfull" });
  } catch (error) {
    console.log(error);
    return res.send({
      status: 400,
      message: "Unable to register, please try again!",
    });
  }
};
