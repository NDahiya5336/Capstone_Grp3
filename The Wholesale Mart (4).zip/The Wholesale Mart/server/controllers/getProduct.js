const Product = require("../models/Product");

const getProductByID = async (req, res) => {
  console.log(req.query.id);

  try {
    const product = await Product.findById(req.query.id);
    res.send(product);
  } catch (error) {
    console.log(error);
    res.send({ status: 400, message: error });
  }
};

const getAllProducts = async (req, res) => {
  const products = await Product.find({});
  console.log(products);
  res.send(products);
};

const getProduct = async (req, res) => {
  console.log(req.params);
  console.log("requested");
  const product = await Product.findById("6426f6ce47d8bfd1c94eb467");

  console.log(product);

  res.send(product);
};

module.exports = { getProductByID, getAllProducts, getProduct };
