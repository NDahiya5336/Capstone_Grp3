const router = require("express").Router();

const {
  getAllProducts,
  getProduct,
  getProductByID,
} = require("../controllers/getProduct");

router.get("/getProduct/:id", getProduct);

router.get("/getProductById", getProductByID);

router.get("/getAllProducts", getAllProducts);

module.exports = router;
