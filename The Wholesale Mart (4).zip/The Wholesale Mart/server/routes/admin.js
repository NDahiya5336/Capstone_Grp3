const router = require("express").Router();

const addProduct = require("../controllers/addProduct");
const uploadImage = require("../middleware/imageUpload");

router.post("/addProduct", uploadImage.array("images", 12), addProduct);

module.exports = router;
