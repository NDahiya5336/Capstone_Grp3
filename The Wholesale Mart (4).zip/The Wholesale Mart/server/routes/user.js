const router = require("express").Router();

const getAddress = require("../controllers/getAddress");
const saveAddress = require("../controllers/saveAddress");

router.get("/getAddress/:id", getAddress);
router.post("/saveAddress", saveAddress);

module.exports = router;
