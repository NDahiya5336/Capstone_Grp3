const router = require("express").Router();

const userRegister = require("../controllers/userRegister");
const userLogin = require("../controllers/userLogin");

const hashPassword = require("../middleware/hashPassword");

router.post("/register", hashPassword, userRegister);
router.post("/login", userLogin);

module.exports = router;
