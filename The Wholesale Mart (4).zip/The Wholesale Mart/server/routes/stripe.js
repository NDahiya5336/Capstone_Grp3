const stripePayment = require("../controllers/stripePayment");

const router = require("express").Router();

router.post("/payment", stripePayment);

module.exports = router;
