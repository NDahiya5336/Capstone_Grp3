const express = require("express");
const cors = require("cors");

require("colors");
require("dotenv").config();

const connectDB = require("./config/db");

const authRouter = require("./routes/auth");
const userRouter = require("./routes/user");
const adminRouter = require("./routes/admin");
const productRouter = require("./routes/product");
const stripeRouter = require("./routes/stripe");

const app = express();

app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use("/uploads", express.static("uploads"));
connectDB();

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.use("/", authRouter);
app.use("/", productRouter);
app.use("/", userRouter);
app.use("/", stripeRouter);
app.use("/admin", adminRouter);

app.listen(process.env.PORT, () =>
  console.log(`Server is running on ${process.env.PORT}`)
);
