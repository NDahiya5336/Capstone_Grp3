const bcrypt = require("bcrypt");

module.exports = async (req, res, next) => {
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(req.body.password, salt);
  req.body.hashedPassword = hashedPassword;
  next();
};
