const mongoose = require("mongoose");

mongoose.set("strictQuery", false);

const connectDB = async () => {
  await mongoose.connect(process.env.MONGO_URI, { dbName: "TheWholesaleMart" });
  console.log("DB is connected.....".cyan.underline.bold);
};

module.exports = connectDB;
